package soltech;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
/*import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;*/

public class login {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\PARVATHI\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(" http://soltech.net/");
		Thread.sleep(3000);
		driver.manage().window().setSize(new Dimension(1814,974));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		
		WebElement career = driver.findElement(By.xpath("//*[@id='navbar']/div/ul/li[5]/a"));
		career.click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		
		String oldTab = driver.getWindowHandle();
		Thread.sleep(200);
		
		driver.findElement(By.xpath("//*[@id='navbar']/div/ul/li[5]/ul/li[2]/a")).click();
		
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
	    newTab.remove(oldTab);
	    
	    // change focus to new tab
	    driver.switchTo().window(newTab.get(0));
	    System.out.println("control is in second tab");
	    Thread.sleep(3000);
	    
	    // Scrolling to the End of the page
	    Actions actions = new Actions(driver);
	    actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
	    
	    //Switching to Frame
	    WebElement iframe =driver.findElement(By.xpath("//iframe[@id='icims_content_iframe']"));
	    driver.switchTo().frame(iframe);

		WebElement searchkeyfield = driver.findElement(By.xpath("//*[@id='jsb_f_keywords_i']"));
		searchkeyfield.sendKeys("QA");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		
		WebElement submit = driver.findElement(By.xpath("//*[@id='jsb_form_submit_i']"));
		submit.click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		WebElement qalink=driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[16]/td[1]/a"));
		qalink.click();
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		String a= driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div[1]/div/div/div/dl[1]/dd")).getText();
		System.out.println("Job ID is " +a);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		
		//apply
		driver.findElement(By.xpath("//*[@id='jobOptionsMobile']/a[1]/div")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		System.out.println("apply page loaded successfully");
		
		//refer
		driver.get("https://careers-soltech.icims.com/jobs/1958/quality-assurance-automation-engineer/job");
		WebElement iframe1 =driver.findElement(By.xpath("//iframe[@id='icims_content_iframe']"));
	    driver.switchTo().frame(iframe1);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		driver.findElement(By.xpath("//*[@id='jobOptionsMobile']/a[3]/div")).click();
		System.out.println("refer page loaded successfully");
		
		//login
		driver.get("https://careers-soltech.icims.com/jobs/1958/quality-assurance-automation-engineer/job");
		Alert alert = driver.switchTo().alert();
		alert.accept();
		WebElement iframe2 =driver.findElement(By.xpath("//iframe[@id='icims_content_iframe']"));
	    driver.switchTo().frame(iframe2);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		driver.findElement(By.xpath("/html/body/div[2]/div[1]/div/div[1]/div[2]/a")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		driver.get("https://careers-soltech.icims.com/jobs/1958/quality-assurance-automation-engineer/job");
		System.out.println("login back page loaded successfully");
		
		// back to welcome page
		WebElement iframe3 =driver.findElement(By.xpath("//iframe[@id='icims_content_iframe']"));
	    driver.switchTo().frame(iframe3);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div[7]/div/a")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		System.out.println("welcome back page loaded successfully");
		
		
		//back
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("/html/body/header/div[2]/a")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.MILLISECONDS);
		System.out.println("back to main page loaded successfully");
		driver.close();
		
		}
	}


